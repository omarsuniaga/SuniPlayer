// ==================== FIREBASE CLOUD FUNCTIONS ====================
// Deploy with: firebase deploy --only functions

const functions = require('firebase-functions');
const admin = require('firebase-admin');

admin.initializeApp();
const db = admin.database();

// ========== 1. DEVICE HEARTBEAT & CLEANUP ==========
/**
 * Marks devices as inactive if no heartbeat received within 30 seconds
 * Run every 10 seconds
 */
exports.cleanupInactiveDevices = functions
  .pubsub.schedule('every 10 seconds')
  .onRun(async () => {
    const now = Date.now();
    const threshold = 30000; // 30 seconds

    const snapshot = await db.ref('rooms').once('value');
    
    if (snapshot.exists()) {
      const rooms = snapshot.val();
      
      for (const roomId in rooms) {
        const devicesRef = db.ref(`rooms/${roomId}/devices`);
        const devicesSnapshot = await devicesRef.once('value');
        
        if (devicesSnapshot.exists()) {
          const devices = devicesSnapshot.val();
          
          for (const deviceId in devices) {
            const device = devices[deviceId];
            
            // Remove devices older than threshold
            if (now - device.timestamp > threshold) {
              await devicesRef.child(deviceId).remove();
            }
          }
        }
      }
    }

    console.log('Inactive devices cleaned up');
    return null;
  });

// ========== 2. SIGNALING: Forward WebRTC offers/answers ==========
/**
 * Listen for new signaling messages and forward to target peer
 */
exports.handleSignaling = functions.database
  .ref('rooms/{roomId}/signals/{signalId}')
  .onCreate(async (snapshot, context) => {
    const { roomId, signalId } = context.params;
    const signalData = snapshot.val();

    try {
      // Extract: "device_abc_device_xyz" -> device_abc and device_xyz
      const [fromDevice, toDevice] = signalId.split('_');

      if (!toDevice) {
        console.error('Invalid signal format:', signalId);
        return null;
      }

      // Store signal for receiving peer to retrieve
      const forwardRef = db.ref(
        `rooms/${roomId}/signals_received/${toDevice}_from_${fromDevice}`
      );

      await forwardRef.set({
        signal: signalData.signal,
        from: signalData.from,
        timestamp: Date.now()
      });

      console.log(`Signal forwarded: ${fromDevice} -> ${toDevice}`);
      return null;

    } catch (error) {
      console.error('Signaling error:', error);
      return null;
    }
  });

// ========== 3. BROADCAST SYNC COMMAND ==========
/**
 * Broadcast play/pause/song change to all devices in room
 */
exports.broadcastSyncCommand = functions.database
  .ref('rooms/{roomId}/sync_commands')
  .onUpdate(async (change, context) => {
    const { roomId } = context.params;
    const command = change.after.val();

    const devicesSnapshot = await db.ref(`rooms/${roomId}/devices`).once('value');
    
    if (devicesSnapshot.exists()) {
      const devices = devicesSnapshot.val();
      const targetDevices = Object.keys(devices).filter(
        id => id !== command.sourceDevice
      );

      // Notify all devices about the command
      const updates = {};
      targetDevices.forEach(deviceId => {
        updates[`rooms/${roomId}/pending_commands/${deviceId}`] = {
          ...command,
          deliveredAt: Date.now()
        };
      });

      await db.ref().update(updates);
      console.log(`Command broadcast to ${targetDevices.length} devices`);
    }

    return null;
  });

// ========== 4. SYNC METRICS ==========
/**
 * Track sync accuracy metrics for debugging
 */
exports.recordSyncMetric = functions.database
  .ref('rooms/{roomId}/metrics/sync/{metricId}')
  .onCreate(async (snapshot, context) => {
    const { roomId } = context.params;
    const metric = snapshot.val();

    // Aggregate metrics (optional: send to Analytics)
    const metricsRef = db.ref(`rooms/${roomId}/metrics_summary`);
    
    metricsRef.transaction(current => {
      if (!current) {
        return {
          avgDrift: metric.drift,
          maxDrift: metric.drift,
          minDrift: metric.drift,
          sampleCount: 1
        };
      }

      const newAvg = (current.avgDrift * current.sampleCount + metric.drift) 
        / (current.sampleCount + 1);

      return {
        avgDrift: newAvg,
        maxDrift: Math.max(current.maxDrift, metric.drift),
        minDrift: Math.min(current.minDrift, metric.drift),
        sampleCount: current.sampleCount + 1,
        lastUpdate: Date.now()
      };
    });

    console.log(`Sync metric recorded: ${metric.drift}ms drift`);
    return null;
  });

// ========== 5. ROOM MANAGEMENT ==========
/**
 * Initialize room when first device joins
 */
exports.initializeRoom = functions.database
  .ref('rooms/{roomId}/devices/{deviceId}')
  .onCreate(async (snapshot, context) => {
    const { roomId, deviceId } = context.params;

    const configRef = db.ref(`rooms/${roomId}/config`);
    const configSnapshot = await configRef.once('value');

    if (!configSnapshot.exists()) {
      // First device in room - initialize config
      await configRef.set({
        createdAt: Date.now(),
        maxDevices: 10,
        syncInterval: 5000,
        maxDrift: 200,
        status: 'active'
      });

      console.log(`Room ${roomId} initialized`);
    }

    return null;
  });

// ========== 6. CLEANUP EMPTY ROOMS ==========
/**
 * Delete room if empty for 5 minutes
 */
exports.cleanupEmptyRooms = functions
  .pubsub.schedule('every 30 minutes')
  .onRun(async () => {
    const now = Date.now();
    const threshold = 5 * 60 * 1000; // 5 minutes

    const snapshot = await db.ref('rooms').once('value');
    
    if (snapshot.exists()) {
      const rooms = snapshot.val();
      
      for (const roomId in rooms) {
        const configRef = db.ref(`rooms/${roomId}/config`);
        const config = (await configRef.once('value')).val();

        if (config && now - config.createdAt > threshold) {
          const devicesRef = db.ref(`rooms/${roomId}/devices`);
          const devicesSnapshot = await devicesRef.once('value');

          // If no devices, delete entire room
          if (!devicesSnapshot.exists()) {
            await db.ref(`rooms/${roomId}`).remove();
            console.log(`Deleted empty room: ${roomId}`);
          }
        }
      }
    }

    return null;
  });

// ========== 7. LOGGING & ANALYTICS ==========
/**
 * Log connection events for monitoring
 */
exports.logConnectionEvent = functions.database
  .ref('rooms/{roomId}/devices/{deviceId}')
  .onCreate(async (snapshot, context) => {
    const { roomId, deviceId } = context.params;
    const device = snapshot.val();

    console.log(`[CONNECT] Room: ${roomId}, Device: ${deviceId}`);

    // Optional: Send to external analytics service
    // await sendToAnalytics({ event: 'device_connect', roomId, deviceId });

    return null;
  });

exports.logDisconnectionEvent = functions.database
  .ref('rooms/{roomId}/devices/{deviceId}')
  .onDelete(async (snapshot, context) => {
    const { roomId, deviceId } = context.params;

    console.log(`[DISCONNECT] Room: ${roomId}, Device: ${deviceId}`);

    // Optional: Send to external analytics service
    // await sendToAnalytics({ event: 'device_disconnect', roomId, deviceId });

    return null;
  });
