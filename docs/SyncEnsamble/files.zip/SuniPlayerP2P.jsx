import React, { useState, useEffect, useRef } from 'react';
import SimplePeer from 'simple-peer';
import { initializeApp } from 'firebase/app';
import { getDatabase, ref, set, onValue, remove } from 'firebase/database';
import { Music, Play, Pause, Users, Zap, Volume2 } from 'lucide-react';

// ==================== FIREBASE CONFIG ====================
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  databaseURL: "https://YOUR_PROJECT.firebaseio.com",
  projectId: "YOUR_PROJECT",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

const firebaseApp = initializeApp(firebaseConfig);
const database = getDatabase(firebaseApp);

// ==================== MOCK SONG LIBRARY ====================
const SONG_LIBRARY = [
  { id: 'song_1', title: 'Danzón No. 2', artist: 'Arturo Márquez', duration: 480 },
  { id: 'song_2', title: 'Carmen Suite', artist: 'Bizet', duration: 420 },
  { id: 'song_3', title: 'Concierto de Aranjuez', artist: 'Rodrigo', duration: 540 },
  { id: 'song_4', title: 'El Amor Brujo', artist: 'Falla', duration: 360 },
  { id: 'song_5', title: 'Czardas', artist: 'Vittorio Monti', duration: 300 },
];

// ==================== MAIN COMPONENT ====================
const SuniPlayerP2P = () => {
  // ========== STATE ==========
  const [deviceId] = useState(() => 
    `device_${Math.random().toString(36).substr(2, 9)}`
  );
  const [peers, setPeers] = useState({});
  const [connectedDevices, setConnectedDevices] = useState([]);
  const [currentSong, setCurrentSong] = useState(SONG_LIBRARY[0]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(0.8);
  const [songQueue, setSongQueue] = useState([]);
  const [lastSyncTime, setLastSyncTime] = useState(null);
  const [syncDrift, setSyncDrift] = useState(0);

  // ========== REFS ==========
  const audioRef = useRef(new Audio());
  const peersRef = useRef({});
  const syncIntervalRef = useRef(null);
  const roomIdRef = useRef('suniplayer_room_1');

  // ========== INITIALIZE AUDIO ELEMENT ==========
  useEffect(() => {
    const audio = audioRef.current;
    audio.crossOrigin = "anonymous";
    audio.volume = volume;

    return () => {
      audio.pause();
      audio.currentTime = 0;
    };
  }, []);

  // ========== FIREBASE SIGNALING: Discover peers ==========
  useEffect(() => {
    const roomRef = ref(database, `rooms/${roomIdRef.current}/devices`);
    
    // Register this device
    set(ref(database, `rooms/${roomIdRef.current}/devices/${deviceId}`), {
      deviceId,
      timestamp: Date.now(),
      active: true
    });

    // Listen for other devices
    onValue(roomRef, (snapshot) => {
      if (snapshot.exists()) {
        const devices = Object.values(snapshot.val()).filter(
          d => d.deviceId !== deviceId && Date.now() - d.timestamp < 30000
        );
        setConnectedDevices(devices);

        // Create peers for new devices
        devices.forEach(device => {
          if (!peersRef.current[device.deviceId]) {
            createPeerConnection(device.deviceId, true);
          }
        });
      }
    });

    // Cleanup on unmount
    return () => {
      remove(ref(database, `rooms/${roomIdRef.current}/devices/${deviceId}`));
    };
  }, [deviceId]);

  // ========== WEBRTC PEER CONNECTION ==========
  const createPeerConnection = (targetDeviceId, initiator) => {
    const peer = new SimplePeer({
      initiator,
      trickle: true,
      streams: [],
      config: {
        iceServers: [
          { urls: 'stun:stun.l.google.com:19302' },
          { urls: 'stun:stun1.l.google.com:19302' }
        ]
      }
    });

    const dataChannel = peer.createDataChannel ? 
      peer.createDataChannel('sync') : null;

    // Handle incoming data channel
    peer.on('data', (data) => {
      handlePeerMessage(JSON.parse(data.toString()));
    });

    // Handle signal for Firebase signaling
    peer.on('signal', (signal) => {
      set(
        ref(database, `rooms/${roomIdRef.current}/signals/${deviceId}_${targetDeviceId}`),
        { signal: JSON.stringify(signal), from: deviceId }
      );
    });

    peer.on('error', (err) => {
      console.error(`Peer error with ${targetDeviceId}:`, err);
      delete peersRef.current[targetDeviceId];
    });

    peer.on('close', () => {
      delete peersRef.current[targetDeviceId];
    });

    peersRef.current[targetDeviceId] = peer;
    setPeers({ ...peersRef.current });
  };

  // ========== HANDLE PEER MESSAGES ==========
  const handlePeerMessage = (message) => {
    switch (message.type) {
      case 'PLAY_SONG':
        setCurrentSong(message.song);
        setIsPlaying(true);
        playSong(message.song, message.syncTimestamp);
        break;

      case 'PLAY_PAUSE':
        setIsPlaying(message.isPlaying);
        if (message.isPlaying) {
          audioRef.current.play();
        } else {
          audioRef.current.pause();
        }
        break;

      case 'SYNC_REQUEST':
        const currentTime = audioRef.current.currentTime;
        broadcastMessage({
          type: 'SYNC_RESPONSE',
          currentTime,
          timestamp: Date.now(),
          deviceId
        });
        break;

      case 'SYNC_RESPONSE':
        // Adjust playback based on remote device time
        adjustPlaybackSync(message);
        break;

      case 'QUEUE_UPDATE':
        setSongQueue(message.queue);
        break;

      default:
        break;
    }
  };

  // ========== PLAY SONG WITH SYNC ==========
  const playSong = (song, syncTimestamp = Date.now()) => {
    const audio = audioRef.current;
    
    // Use mock audio URL (replace with actual)
    audio.src = `https://example.com/songs/${song.id}.mp3`;
    
    // Set start time based on sync timestamp
    const delay = (Date.now() - syncTimestamp) / 1000;
    audio.currentTime = Math.max(0, delay);
    
    audio.play().catch(err => console.error('Play error:', err));
    setLastSyncTime(Date.now());
  };

  // ========== ADJUST PLAYBACK SYNC ==========
  const adjustPlaybackSync = (syncResponse) => {
    const audio = audioRef.current;
    const timeDrift = Math.abs(audio.currentTime - syncResponse.currentTime);
    
    setSyncDrift(timeDrift);

    // If drift > 200ms, adjust
    if (timeDrift > 0.2) {
      audio.currentTime = syncResponse.currentTime;
    }
  };

  // ========== BROADCAST MESSAGE TO ALL PEERS ==========
  const broadcastMessage = (message) => {
    Object.values(peersRef.current).forEach(peer => {
      try {
        peer.send(JSON.stringify(message));
      } catch (err) {
        console.error('Send error:', err);
      }
    });
  };

  // ========== CONTINUOUS SYNC LOOP ==========
  useEffect(() => {
    syncIntervalRef.current = setInterval(() => {
      if (isPlaying && lastSyncTime) {
        broadcastMessage({
          type: 'SYNC_REQUEST',
          timestamp: Date.now()
        });
      }
    }, 5000); // Sync every 5 seconds

    return () => clearInterval(syncIntervalRef.current);
  }, [isPlaying, lastSyncTime]);

  // ========== HANDLE SONG SELECTION ==========
  const selectSong = (song) => {
    const syncTimestamp = Date.now();
    
    setCurrentSong(song);
    setIsPlaying(true);
    playSong(song, syncTimestamp);
    
    broadcastMessage({
      type: 'PLAY_SONG',
      song,
      syncTimestamp,
      deviceId
    });
  };

  // ========== TOGGLE PLAY/PAUSE ==========
  const togglePlayPause = () => {
    const newState = !isPlaying;
    setIsPlaying(newState);

    if (newState) {
      audioRef.current.play();
    } else {
      audioRef.current.pause();
    }

    broadcastMessage({
      type: 'PLAY_PAUSE',
      isPlaying: newState,
      deviceId
    });
  };

  // ========== HANDLE VOLUME CHANGE ==========
  const handleVolumeChange = (e) => {
    const newVolume = parseFloat(e.target.value);
    setVolume(newVolume);
    audioRef.current.volume = newVolume;
  };

  // ========== RENDER ==========
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white p-8">
      <div className="max-w-6xl mx-auto">
        
        {/* HEADER */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <Music className="w-8 h-8 text-purple-400" />
            <h1 className="text-4xl font-bold">SuniPlayer P2P</h1>
          </div>
          <p className="text-slate-300 text-sm">Reproducción sincronizada en múltiples dispositivos</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* MAIN PLAYER */}
          <div className="lg:col-span-2">
            
            {/* CURRENT SONG */}
            <div className="bg-gradient-to-br from-purple-600 to-purple-800 rounded-xl p-8 mb-6 shadow-xl">
              <div className="text-center mb-6">
                <Music className="w-16 h-16 mx-auto mb-4 text-purple-200" />
                <h2 className="text-3xl font-bold mb-2">{currentSong.title}</h2>
                <p className="text-purple-200">{currentSong.artist}</p>
                <p className="text-sm text-purple-300 mt-2">
                  Duración: {Math.floor(currentSong.duration / 60)}:{String(currentSong.duration % 60).padStart(2, '0')}
                </p>
              </div>

              {/* PLAYBACK CONTROLS */}
              <div className="flex items-center justify-center gap-6 mb-6">
                <button
                  onClick={togglePlayPause}
                  className="bg-white text-purple-600 rounded-full p-4 hover:bg-purple-100 transition shadow-lg"
                >
                  {isPlaying ? (
                    <Pause className="w-8 h-8" />
                  ) : (
                    <Play className="w-8 h-8" />
                  )}
                </button>
                <div className="text-center">
                  <p className="text-sm text-purple-200 mb-1">Estado</p>
                  <span className={`inline-block px-3 py-1 rounded-full text-xs font-bold ${
                    isPlaying 
                      ? 'bg-green-500 text-white' 
                      : 'bg-slate-600 text-slate-200'
                  }`}>
                    {isPlaying ? 'Reproduciendo' : 'Pausado'}
                  </span>
                </div>
              </div>

              {/* SYNC STATUS */}
              <div className="bg-black bg-opacity-30 rounded-lg p-4 text-center">
                <p className="text-xs text-slate-300 mb-1">Desincronización detectada</p>
                <p className={`text-lg font-mono ${syncDrift < 0.1 ? 'text-green-400' : 'text-yellow-400'}`}>
                  {(syncDrift * 1000).toFixed(0)}ms
                </p>
              </div>
            </div>

            {/* VOLUME CONTROL */}
            <div className="bg-slate-800 rounded-xl p-6 mb-6">
              <div className="flex items-center gap-4">
                <Volume2 className="w-5 h-5 text-slate-400" />
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.01"
                  value={volume}
                  onChange={handleVolumeChange}
                  className="flex-1 h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer"
                />
                <span className="text-sm text-slate-300 min-w-10">
                  {Math.round(volume * 100)}%
                </span>
              </div>
            </div>

            {/* SONG LIBRARY */}
            <div className="bg-slate-800 rounded-xl p-6">
              <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                <Music className="w-5 h-5 text-purple-400" />
                Biblioteca de Canciones
              </h3>
              <div className="space-y-2">
                {SONG_LIBRARY.map(song => (
                  <button
                    key={song.id}
                    onClick={() => selectSong(song)}
                    className={`w-full text-left p-4 rounded-lg transition ${
                      currentSong.id === song.id
                        ? 'bg-purple-600 text-white'
                        : 'bg-slate-700 hover:bg-slate-600 text-slate-200'
                    }`}
                  >
                    <div className="font-semibold">{song.title}</div>
                    <div className="text-sm opacity-75">{song.artist} • {Math.floor(song.duration / 60)}:{String(song.duration % 60).padStart(2, '0')}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* SIDEBAR: CONNECTED DEVICES */}
          <div className="bg-slate-800 rounded-xl p-6 h-fit">
            <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
              <Users className="w-5 h-5 text-blue-400" />
              Dispositivos Conectados
            </h3>

            {/* THIS DEVICE */}
            <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-lg p-4 mb-4">
              <div className="flex items-center gap-2 mb-2">
                <Zap className="w-4 h-4 text-yellow-300" />
                <p className="font-semibold text-sm">Este Dispositivo</p>
              </div>
              <p className="text-xs text-blue-100 font-mono break-all">{deviceId}</p>
            </div>

            {/* CONNECTED PEERS */}
            <div className="space-y-3">
              {connectedDevices.length === 0 ? (
                <p className="text-slate-400 text-sm py-4 text-center">
                  Esperando otros dispositivos...
                </p>
              ) : (
                connectedDevices.map(device => (
                  <div key={device.deviceId} className="bg-slate-700 rounded-lg p-3 border border-slate-600">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="w-2 h-2 bg-green-500 rounded-full" />
                      <p className="text-xs font-semibold text-slate-200">Conectado</p>
                    </div>
                    <p className="text-xs text-slate-400 font-mono">{device.deviceId}</p>
                  </div>
                ))
              )}
            </div>

            {/* STATS */}
            <div className="mt-6 pt-4 border-t border-slate-700">
              <div className="space-y-2 text-xs">
                <div>
                  <p className="text-slate-400">Dispositivos activos</p>
                  <p className="text-lg font-bold text-purple-400">{connectedDevices.length + 1}</p>
                </div>
                <div>
                  <p className="text-slate-400">Conexiones P2P</p>
                  <p className="text-lg font-bold text-blue-400">{Object.keys(peersRef.current).length}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SuniPlayerP2P;
