// ==================== NETWORK & BLUETOOTH OPTIMIZATION ====================

// ========== 1. NETWORK QUALITY MONITOR ==========
export class NetworkQualityMonitor {
  constructor() {
    this.bandwidth = null;
    this.latency = null;
    this.jitter = null;
    this.packetLoss = null;
    this.measurements = [];
  }

  /**
   * Realiza un test de ancho de banda (descarga pequeño archivo)
   */
  async testBandwidth() {
    const fileSize = 1024 * 100; // 100KB
    const url = `data:image/jpeg;base64,${new Array(fileSize).fill('A').join('')}`;

    const start = performance.now();
    try {
      const response = await fetch(url);
      await response.blob();
      const duration = (performance.now() - start) / 1000; // segundos

      this.bandwidth = (fileSize / duration / 1024 / 1024).toFixed(2); // MB/s
      return this.bandwidth;
    } catch (err) {
      console.error('Bandwidth test error:', err);
      return null;
    }
  }

  /**
   * Mide latencia usando WebRTC stats
   */
  async measureLatencyWebRTC(peerConnection) {
    try {
      const stats = await peerConnection.getStats();
      let minRoundTripTime = Infinity;

      stats.forEach(report => {
        if (report.type === 'inbound-rtp' || report.type === 'outbound-rtp') {
          if (report.roundTripTime !== undefined) {
            minRoundTripTime = Math.min(minRoundTripTime, report.roundTripTime * 1000);
          }
        }
      });

      this.latency = minRoundTripTime === Infinity ? null : minRoundTripTime.toFixed(2);
      return this.latency;
    } catch (err) {
      console.error('RTT measurement error:', err);
      return null;
    }
  }

  /**
   * Calcula jitter (variabilidad de latencia)
   */
  calculateJitter() {
    if (this.measurements.length < 2) return null;

    let sumDifferences = 0;
    for (let i = 1; i < this.measurements.length; i++) {
      sumDifferences += Math.abs(
        this.measurements[i] - this.measurements[i - 1]
      );
    }

    this.jitter = (sumDifferences / (this.measurements.length - 1)).toFixed(2);
    return this.jitter;
  }

  /**
   * Obtiene reporte de calidad de red
   */
  getNetworkQuality() {
    return {
      bandwidth: this.bandwidth,
      latency: this.latency,
      jitter: this.jitter,
      packetLoss: this.packetLoss,
      recommended: this.getRecommendations()
    };
  }

  getRecommendations() {
    const recommendations = [];

    if (this.latency > 150) {
      recommendations.push('⚠️ Latencia alta - reduce dispositivos conectados');
    }

    if (this.jitter > 50) {
      recommendations.push('⚠️ Jitter alto - verifica conexión WiFi');
    }

    if (this.bandwidth < 5) {
      recommendations.push('⚠️ Ancho de banda bajo - acércate al router');
    }

    if (recommendations.length === 0) {
      recommendations.push('✅ Condiciones de red óptimas');
    }

    return recommendations;
  }
}

// ========== 2. BLUETOOTH AUDIO ROUTING ==========
export class BluetoothAudioRouter {
  constructor() {
    this.isBluetoothConnected = false;
    this.connectedDevices = [];
    this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
    this.analyser = this.audioContext.createAnalyser();
  }

  /**
   * Detecta dispositivos Bluetooth disponibles
   * (Nota: Requiere permisos de usuario)
   */
  async requestBluetoothDevices() {
    try {
      // Esta es la Web Bluetooth API (experimental)
      if (!navigator.bluetooth) {
        console.warn('Web Bluetooth API no disponible');
        return false;
      }

      const device = await navigator.bluetooth.requestDevice({
        filters: [
          { services: ['audio'] },
          { services: ['audio/control'] }
        ]
      });

      console.log(`📱 Dispositivo Bluetooth seleccionado: ${device.name}`);
      return device;

    } catch (error) {
      console.error('Error requesting Bluetooth device:', error);
      return false;
    }
  }

  /**
   * Routea audio a Bluetooth (a través del SO)
   * Nota: En navegadores, el SO maneja esto automáticamente
   */
  async routeAudioToBluetoothDevice(audioElement) {
    try {
      // En navegadores modernos, esto se maneja automáticamente
      // Pero podemos detectar si hay dispositivo Bluetooth activo

      const source = this.audioContext.createMediaElementAudioSource(audioElement);
      source.connect(this.analyser);
      this.analyser.connect(this.audioContext.destination);

      console.log('✅ Audio ruteado a dispositivo de salida (Bluetooth si está disponible)');
      return true;

    } catch (error) {
      console.error('Error routing audio:', error);
      return false;
    }
  }

  /**
   * Obtiene frecuencias de audio en tiempo real (para visualizar)
   */
  getAudioFrequencies() {
    const dataArray = new Uint8Array(this.analyser.frequencyBinCount);
    this.analyser.getByteFrequencyData(dataArray);
    return dataArray;
  }

  /**
   * Amplifica/normaliza audio
   */
  setAudioGain(gainValue) {
    const gainNode = this.audioContext.createGain();
    gainNode.gain.value = gainValue; // 0.0 - 1.0+

    return gainNode;
  }

  /**
   * Crea ecualizador básico
   */
  createEqualizer() {
    const bass = this.audioContext.createBiquadFilter();
    bass.type = 'lowshelf';
    bass.frequency.value = 200;

    const mid = this.audioContext.createBiquadFilter();
    mid.type = 'peaking';
    mid.frequency.value = 1000;

    const treble = this.audioContext.createBiquadFilter();
    treble.type = 'highshelf';
    treble.frequency.value = 3000;

    return { bass, mid, treble };
  }
}

// ========== 3. WiFi OPTIMIZATION ==========
export class WiFiOptimizer {
  constructor() {
    this.signalStrength = null;
    this.channel = null;
    this.frequency = null;
  }

  /**
   * Obtiene señal WiFi (solo en algunos navegadores/OS)
   */
  async getWiFiSignalStrength() {
    try {
      // Nota: Esto requiere permisos especiales y no está disponible en todos los navegadores
      const networks = await navigator.getNetworkInformation?.();

      if (networks) {
        console.log('📡 Tipo de conexión:', networks.effectiveType);
        console.log('📊 Downlink:', networks.downlink, 'Mbps');
        console.log('⏱️ RTT:', networks.rtt, 'ms');
        return networks;
      }

      return null;
    } catch (error) {
      console.error('Error getting WiFi info:', error);
      return null;
    }
  }

  /**
   * Sugerencias para optimizar WiFi
   */
  getWiFiOptimizationTips() {
    return [
      '📶 Acércate al router WiFi',
      '🔄 Cambia a banda 5GHz si está disponible',
      '❌ Apaga otros dispositivos WiFi que no uses',
      '🛡️ Usa 2.4GHz para mayor alcance, 5GHz para mejor latencia',
      '⏰ Evita usar WiFi compartida con muchos dispositivos',
      '🎯 Coloca el router en posición central'
    ];
  }

  /**
   * Recomendaciones basadas en calidad de conexión
   */
  getConnectionRecommendations(networkQuality) {
    const recommendations = [];

    if (networkQuality.latency > 100) {
      recommendations.push('Considera usar banda 5GHz en lugar de 2.4GHz');
      recommendations.push('Reduce el número de dispositivos conectados');
    }

    if (networkQuality.jitter > 30) {
      recommendations.push('Mueve el router lejos de microondas y teléfonos inalámbricos');
      recommendations.push('Intenta usar WiFi en lugar de cellular');
    }

    return recommendations;
  }
}

// ========== 4. ADAPTIVE SYNC STRATEGY ==========
export class AdaptiveSyncStrategy {
  constructor() {
    this.networkQuality = 'unknown';
    this.syncInterval = 5000; // 5 segundos por defecto
    this.maxDrift = 200; // 200ms por defecto
  }

  /**
   * Ajusta estrategia de sincronización basada en calidad de red
   */
  adjustStrategy(latency, jitter, bandwidth) {
    let quality = 'excellent';

    if (latency > 150 || jitter > 50 || bandwidth < 5) {
      quality = 'poor';
      this.syncInterval = 2000; // Sincronizar cada 2 segundos
      this.maxDrift = 100;
    } else if (latency > 100 || jitter > 30) {
      quality = 'fair';
      this.syncInterval = 3000;
      this.maxDrift = 150;
    } else if (latency > 50 || jitter > 15) {
      quality = 'good';
      this.syncInterval = 4000;
      this.maxDrift = 100;
    } else {
      quality = 'excellent';
      this.syncInterval = 5000;
      this.maxDrift = 50;
    }

    this.networkQuality = quality;

    return {
      quality,
      syncInterval: this.syncInterval,
      maxDrift: this.maxDrift,
      recommendations: this.getRecommendations(quality)
    };
  }

  getRecommendations(quality) {
    const tips = {
      excellent: '✅ Condiciones óptimas - Sin cambios necesarios',
      good: '⚠️ Buena calidad - Monitorea la conexión',
      fair: '⚠️ Calidad aceptable - Considera cambiar ubicación',
      poor: '❌ Calidad pobre - Mejora tu conexión WiFi'
    };

    return tips[quality] || tips.unknown;
  }
}

// ========== 5. CONNECTION DIAGNOSTICS ==========
export class ConnectionDiagnostics {
  static async runFullDiagnostics() {
    const results = {
      timestamp: new Date().toISOString(),
      browser: this.getBrowserInfo(),
      network: this.getNetworkInfo(),
      webrtc: await this.testWebRTC(),
      bluetooth: this.checkBluetoothSupport()
    };

    return results;
  }

  static getBrowserInfo() {
    const ua = navigator.userAgent;
    return {
      userAgent: ua,
      platform: navigator.platform,
      language: navigator.language,
      onLine: navigator.onLine
    };
  }

  static getNetworkInfo() {
    const connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;

    if (connection) {
      return {
        effectiveType: connection.effectiveType,
        downlink: connection.downlink,
        rtt: connection.rtt,
        saveData: connection.saveData
      };
    }

    return { info: 'Network Information API no disponible' };
  }

  static async testWebRTC() {
    try {
      const peerConnection = new RTCPeerConnection();
      const offer = await peerConnection.createOffer();

      return {
        supported: true,
        dataChannels: true,
        iceCandidates: true,
        message: 'WebRTC funcionando correctamente'
      };

    } catch (error) {
      return {
        supported: false,
        error: error.message
      };
    }
  }

  static checkBluetoothSupport() {
    return {
      supported: !!navigator.bluetooth,
      api: navigator.bluetooth ? 'Web Bluetooth API' : 'No disponible'
    };
  }

  static generateReport(diagnostics) {
    console.log('=== 📊 SUNIPLAYER DIAGNOSTICS REPORT ===');
    console.log(JSON.stringify(diagnostics, null, 2));
    console.log('=======================================');

    return diagnostics;
  }
}

// ========== 6. EXAMPLE USAGE ==========
/*
// En tu componente React:

import {
  NetworkQualityMonitor,
  BluetoothAudioRouter,
  WiFiOptimizer,
  AdaptiveSyncStrategy,
  ConnectionDiagnostics
} from './network-utils';

// Monitorear calidad
const monitor = new NetworkQualityMonitor();
const bandwidth = await monitor.testBandwidth();
console.log('Ancho de banda:', bandwidth, 'MB/s');

// Routed audio to Bluetooth
const router = new BluetoothAudioRouter();
await router.routeAudioToBluetoothDevice(audioElement);

// Get WiFi tips
const wifiOptimizer = new WiFiOptimizer();
console.log(wifiOptimizer.getWiFiOptimizationTips());

// Adaptive sync
const adaptiveSync = new AdaptiveSyncStrategy();
const strategy = adaptiveSync.adjustStrategy(latency, jitter, bandwidth);
console.log('Sync strategy:', strategy);

// Full diagnostics
const diagnostics = await ConnectionDiagnostics.runFullDiagnostics();
ConnectionDiagnostics.generateReport(diagnostics);
*/
