// ==================== SUNIPLAYER P2P - TEST & DEBUG UTILITIES ====================

// ========== 1. SIMULATED PEER CONNECTION (para testing sin 3 dispositivos) ==========
export class SimulatedPeerConnection {
  constructor(targetId) {
    this.targetId = targetId;
    this.isConnected = false;
    this.messageQueue = [];
    this.latency = Math.random() * 50 + 20; // 20-70ms
  }

  connect() {
    this.isConnected = true;
    console.log(`[SIM] Conexión simulada con ${this.targetId}`);
  }

  send(message) {
    if (!this.isConnected) {
      console.warn(`[SIM] No conectado a ${this.targetId}`);
      return;
    }

    // Simular latencia
    setTimeout(() => {
      this.messageQueue.push(message);
      console.log(
        `[SIM] Mensaje recibido en ${this.targetId} después de ${this.latency.toFixed(0)}ms`
      );
    }, this.latency);
  }

  getQueuedMessages() {
    return this.messageQueue.splice(0, this.messageQueue.length);
  }

  close() {
    this.isConnected = false;
    console.log(`[SIM] Desconectado de ${this.targetId}`);
  }
}

// ========== 2. LATENCY SIMULATOR ==========
export class LatencySimulator {
  constructor(minMs = 20, maxMs = 100) {
    this.minMs = minMs;
    this.maxMs = maxMs;
    this.measurements = [];
  }

  /**
   * Simula latencia variable de red
   */
  simulateNetworkDelay() {
    return Math.random() * (this.maxMs - this.minMs) + this.minMs;
  }

  /**
   * Simula packet loss (0.0 - 1.0)
   */
  shouldDropPacket(lossRate = 0.05) {
    return Math.random() < lossRate;
  }

  /**
   * Mide la calidad de la red
   */
  getNetworkQuality() {
    if (this.measurements.length === 0) return 'unknown';

    const avgLatency = this.measurements.reduce((a, b) => a + b, 0) / this.measurements.length;

    if (avgLatency < 30) return 'excellent';
    if (avgLatency < 70) return 'good';
    if (avgLatency < 150) return 'fair';
    return 'poor';
  }

  recordMeasurement(latencyMs) {
    this.measurements.push(latencyMs);
    if (this.measurements.length > 100) {
      this.measurements.shift(); // Keep last 100
    }
  }

  getAverageLatency() {
    if (this.measurements.length === 0) return 0;
    return (this.measurements.reduce((a, b) => a + b, 0) / this.measurements.length).toFixed(2);
  }

  reset() {
    this.measurements = [];
  }
}

// ========== 3. SYNC QUALITY ANALYZER ==========
export class SyncQualityAnalyzer {
  constructor() {
    this.syncEvents = [];
    this.driftHistory = [];
  }

  /**
   * Registra un evento de sincronización
   */
  recordSync(deviceId, expectedTime, actualTime, drift) {
    this.syncEvents.push({
      timestamp: Date.now(),
      deviceId,
      expectedTime,
      actualTime,
      drift
    });

    this.driftHistory.push(drift);

    if (this.driftHistory.length > 1000) {
      this.driftHistory.shift();
    }
  }

  /**
   * Calcula estadísticas de sincronización
   */
  getAnalysis() {
    if (this.driftHistory.length === 0) {
      return { status: 'no data' };
    }

    const avgDrift = this.driftHistory.reduce((a, b) => a + b, 0) / this.driftHistory.length;
    const maxDrift = Math.max(...this.driftHistory);
    const minDrift = Math.min(...this.driftHistory);
    const stdDev = this.calculateStdDev(this.driftHistory);

    return {
      sampleCount: this.driftHistory.length,
      avgDrift: avgDrift.toFixed(2),
      maxDrift: maxDrift.toFixed(2),
      minDrift: minDrift.toFixed(2),
      stdDev: stdDev.toFixed(2),
      status: this.getStatus(avgDrift),
      quality: this.getQuality(avgDrift)
    };
  }

  calculateStdDev(values) {
    const avg = values.reduce((a, b) => a + b, 0) / values.length;
    const squareDiffs = values.map(value => Math.pow(value - avg, 2));
    return Math.sqrt(squareDiffs.reduce((a, b) => a + b, 0) / values.length);
  }

  getStatus(avgDrift) {
    if (avgDrift < 50) return '✅ Sincronizado perfectamente';
    if (avgDrift < 100) return '⚠️ Sincronizado bien';
    if (avgDrift < 200) return '⚡ Sincronización aceptable';
    return '❌ Sincronización pobre';
  }

  getQuality(avgDrift) {
    if (avgDrift < 50) return 'excellent';
    if (avgDrift < 100) return 'good';
    if (avgDrift < 200) return 'fair';
    return 'poor';
  }

  clear() {
    this.syncEvents = [];
    this.driftHistory = [];
  }
}

// ========== 4. DEVICE SIMULATOR (Múltiples dispositivos simulados) ==========
export class DeviceSimulator {
  constructor(deviceId) {
    this.deviceId = deviceId;
    this.currentSong = null;
    this.isPlaying = false;
    this.currentTime = 0;
    this.messageLog = [];
    this.startTime = null;
  }

  playSong(song, syncTimestamp) {
    this.currentSong = song;
    this.isPlaying = true;
    this.startTime = syncTimestamp;
    this.currentTime = (Date.now() - syncTimestamp) / 1000;

    this.log('PLAY_SONG', { song: song.title });
  }

  pause() {
    this.isPlaying = false;
    this.log('PAUSE', {});
  }

  resume() {
    this.isPlaying = true;
    this.startTime = Date.now() - (this.currentTime * 1000);
    this.log('RESUME', {});
  }

  getCurrentTime() {
    if (!this.isPlaying || !this.startTime) return 0;
    return (Date.now() - this.startTime) / 1000;
  }

  getDrift(referenceTime) {
    const diff = this.getCurrentTime() - referenceTime;
    return diff * 1000; // Convert to milliseconds
  }

  log(action, data) {
    this.messageLog.push({
      timestamp: Date.now(),
      action,
      data
    });
  }

  getMessageLog() {
    return this.messageLog;
  }

  clearLog() {
    this.messageLog = [];
  }
}

// ========== 5. TEST SUITE ==========
export class SuniPlayerTestSuite {
  /**
   * Test: Todas las canciones cargan correctamente
   */
  static testSongLibraryLoad(library) {
    console.log('🧪 TEST: Song Library Load');
    const results = library.map(song => ({
      id: song.id,
      title: song.title,
      duration: song.duration,
      valid: song.id && song.title && song.duration > 0
    }));

    const allValid = results.every(r => r.valid);
    console.log(allValid ? '✅ PASS' : '❌ FAIL', results);
    return allValid;
  }

  /**
   * Test: Sincronización de dos dispositivos
   */
  static testTwoDeviceSync(device1, device2, song) {
    console.log('🧪 TEST: Two Device Sync');

    const syncTime = Date.now();
    device1.playSong(song, syncTime);
    device2.playSong(song, syncTime);

    // Simular 5 segundos de reproducción
    for (let i = 0; i < 5; i++) {
      setTimeout(() => {
        const drift = Math.abs(device1.getCurrentTime() - device2.getCurrentTime()) * 1000;
        console.log(`[${i}s] Drift: ${drift.toFixed(0)}ms`);

        if (drift > 200) {
          console.log('❌ FAIL: Drift > 200ms');
          return false;
        }
      }, i * 1000);
    }

    console.log('✅ PASS: Sincronización exitosa');
    return true;
  }

  /**
   * Test: Tolerancia a latencia de red
   */
  static testLatencyTolerance() {
    console.log('🧪 TEST: Latency Tolerance');

    const simulator = new LatencySimulator(20, 100);
    const latencies = [];

    for (let i = 0; i < 100; i++) {
      latencies.push(simulator.simulateNetworkDelay());
    }

    const avg = latencies.reduce((a, b) => a + b, 0) / latencies.length;
    console.log(`✅ PASS: Average latency: ${avg.toFixed(2)}ms, Quality: ${simulator.getNetworkQuality()}`);

    return avg < 150;
  }

  /**
   * Test: Recuperación de desincronización
   */
  static testDesyncRecovery() {
    console.log('🧪 TEST: Desync Recovery');

    const analyzer = new SyncQualityAnalyzer();

    // Simular desincronizaciones
    for (let i = 0; i < 50; i++) {
      const drift = Math.random() * 300; // 0-300ms drift
      analyzer.recordSync('device_1', 10 + i, 10 + i + (drift / 1000), drift);
    }

    const analysis = analyzer.getAnalysis();
    console.log('✅ PASS', analysis);

    return analysis.quality !== 'poor';
  }

  /**
   * Test: Multi-device broadcast
   */
  static testMultiDeviceBroadcast(devices) {
    console.log('🧪 TEST: Multi-Device Broadcast');

    const song = { id: 'test', title: 'Test Song', duration: 180 };
    const syncTime = Date.now();

    // Master device sends song
    devices[0].playSong(song, syncTime);

    // Verify all devices receive
    const allPlaying = devices.every(d => d.currentSong?.id === song.id);

    console.log(allPlaying ? '✅ PASS: All devices received song' : '❌ FAIL: Not all devices synchronized');

    return allPlaying;
  }
}

// ========== 6. DEBUG LOGGER ==========
export class DebugLogger {
  constructor(prefix = 'SuniPlayer') {
    this.prefix = prefix;
    this.logs = [];
    this.isEnabled = true;
  }

  log(level, message, data = {}) {
    const timestamp = new Date().toLocaleTimeString();
    const entry = {
      timestamp,
      level,
      message,
      data
    };

    this.logs.push(entry);

    if (this.isEnabled) {
      const color = {
        'INFO': 'color: #0EA5E9',
        'WARN': 'color: #F59E0B',
        'ERROR': 'color: #EF4444',
        'SUCCESS': 'color: #10B981'
      }[level] || 'color: #6B7280';

      console.log(
        `%c[${this.prefix}] ${timestamp} ${level}`,
        color,
        message,
        data
      );
    }
  }

  info(message, data) { this.log('INFO', message, data); }
  warn(message, data) { this.log('WARN', message, data); }
  error(message, data) { this.log('ERROR', message, data); }
  success(message, data) { this.log('SUCCESS', message, data); }

  getLogs(filter = null) {
    return filter ? this.logs.filter(l => l.level === filter) : this.logs;
  }

  exportLogs() {
    return JSON.stringify(this.logs, null, 2);
  }

  clear() {
    this.logs = [];
  }

  disable() { this.isEnabled = false; }
  enable() { this.isEnabled = true; }
}

// ========== 7. EXAMPLE USAGE ==========
/*
// En tu componente React:

import {
  LatencySimulator,
  SyncQualityAnalyzer,
  DeviceSimulator,
  SuniPlayerTestSuite,
  DebugLogger
} from './debug-utils';

const logger = new DebugLogger('SuniPlayer');

// Log events
logger.info('Dispositivo conectado', { deviceId: 'device_123' });
logger.success('Canción reproduciendo', { song: 'Danzón No. 2' });

// Analizar sincronización
const analyzer = new SyncQualityAnalyzer();
analyzer.recordSync('device_1', 10.5, 10.6, 100);
console.log(analyzer.getAnalysis());

// Simular dispositivos
const sim1 = new DeviceSimulator('device_1');
const sim2 = new DeviceSimulator('device_2');
SuniPlayerTestSuite.testTwoDeviceSync(sim1, sim2, { id: 'test', title: 'Test', duration: 300 });
*/
